package stepDefinitions;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.support.ui.WebDriverWait;

public class BaseClass {
//create a new instance of the Chrome driver
	static WebDriver driver;
	static WebDriverWait wait;

}
